"""
Core Application Module
"""
